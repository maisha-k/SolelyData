## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(SolelyData)

## -----------------------------------------------------------------------------
missingsum(animalshelter) # Calculates the sum of missing values in the dataset using default settings, including NA handling


## -----------------------------------------------------------------------------
missingsum(animalshelter, missing_values = numeric(0) ) 
# Captures missing values that are NA even when `missing_values` is an empty numeric vector. 
# This flexibility allows the function to handle default missing values or custom definitions effectively.

## -----------------------------------------------------------------------------
plot_completeness(animalshelter, title = "Completeness of Animal Shelter Data")

## -----------------------------------------------------------------------------
# Sample dataset
data <- data.frame(
  Fruit = c("apple", "APPLE", "appl", "orange","orange" ,"banana", "BANANA", "banan", "grap"),
  stringsAsFactors = FALSE
)

## -----------------------------------------------------------------------------
solotypo(data, column = "Fruit")


## -----------------------------------------------------------------------------
solotypo(data, column = "Fruit", threshold = 0.8)


## -----------------------------------------------------------------------------
# Sample dataset
dates <- data.frame(
  Event = c("Meeting", "Deadline", "Conference", "Holiday"),
  Date = c("2024-12-10", "12/25/2024", "2024-13-01", "2024-12-09"), # Includes invalid date "2024-13-01" and "12/25/2024"
  stringsAsFactors = FALSE
)

validate_dates(dates, date_columns  = "Date")


## -----------------------------------------------------------------------------
validate_dates(animalshelter, date_columns = "Date") 

## -----------------------------------------------------------------------------
validate_dates(animalshelter, date_columns = "Date", min_year = 2020, max_year = 2023) 

## -----------------------------------------------------------------------------
animalshelter_flag <- flagweirdanimals(animalshelter, column = "animal_type", valid_types = c("dog", "cat", "rabbit", "bird"))
# View rows where 'weird' is TRUE
weird_animals <- animalshelter_flag[animalshelter_flag$weird == TRUE, ]
print(weird_animals['animal_type'])


## -----------------------------------------------------------------------------
df <- data.frame(
  a = c(1, 2, "x", 4, NA), 
  b = c("a", "b", "c", "d", "e")
)

# Apply the function
result <- flagnonnumeric(df, "a", threshold = 0.8, replace_with_na = TRUE)

# View the modified data
print(result$data)

# View the flagged non-numeric values
print(result$non_numeric_values)


